/*
 * Created by Ranorex
 * User: AUIT
 * Date: __/__/20__
 * Time: __:__ AM
 *
 */
using System;

namespace MyTestProject
{
	/// <summary>
	/// Description of Config.
	/// </summary>
	public static class Config
	{
		public const int DURATION = 50;

		public static String getPathToCaptureImage() {
			return System.IO.Directory.GetParent(System.IO.Directory.GetCurrentDirectory()).Parent.FullName + "\\Reports\\images";
		}
	}
}
